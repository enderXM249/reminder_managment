from django.urls import path
from . import views

urlpatterns = [
    path('',views.get_index,name='index'),
    path('signin/',views.get_signin,name='signin'),
    path('home/',views.get_home,name='home'),
    path('set_reminder/',views.get_set_reminder,name='set_reminder'),
    path('view_reminder/',views.get_view_reminder,name='view_reminder')
]