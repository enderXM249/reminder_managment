from django.shortcuts import render
from .forms import RegisterUser,UserSignIn,RegisterReminder
from .models  import UserSignUp,Reminder
import hashlib
import datetime

def get_index(request):
    
    register_success_alert = False
    
    if request.method == 'POST':
        fm = RegisterUser(request.POST)
        if fm.is_valid():
            # Collecting user's data
            username = fm.cleaned_data['username']
            password = fm.cleaned_data['password']

            # Hasing the password
            salt = "5gz"
            database_password = password+salt
            hashed_password = hashlib.md5(database_password.encode()).hexdigest()

            # Saving the user's data into the database
            register = UserSignUp(username = username,password = hashed_password)
            register.save()
            register_success_alert = True
    
    fm = RegisterUser()
    return render(request,'index.html',{'form': fm,'register_success_alert': register_success_alert})


def get_signin(request):
    
    user_not_exist_alert = False

    if request.method == 'POST':
        fm = UserSignIn(request.POST)
        if fm.is_valid():
            username = fm.cleaned_data['username']
            password = fm.cleaned_data['password']

            # Hasing the password
            salt = '5gz'
            database_password = password+salt
            hashed_password = hashlib.md5(database_password.encode()).hexdigest()

            user_data = UserSignUp.objects.filter(username = username,password = hashed_password).values()
            
            if user_data.exists():

                user_id = str(user_data[0]['id'])
                username = user_data[0]['username'] 

                request.session['user_id'] = user_id
                request.session['username'] = username

        
                curr_date = datetime.date.today().strftime("%b %d %Y")
                
                return render(request,'home.html',{'username': username,'curr_date': curr_date})
            else:
                user_not_exist_alert = True
                

    fm = UserSignIn()
    return render(request,'signin.html',{'form': fm,'user_not_exist_alert': user_not_exist_alert})

def get_home(request):
    return render(request,'home.html')

def get_set_reminder(request):

    reminder_date = None
    reminder_success_alert = False

    if request.method == 'POST':
        fm = RegisterReminder(request.POST)
        if fm.is_valid():
            user_id = request.session['user_id']
            reminder_name = fm.cleaned_data['reminder_name']
            reminder_date = fm.cleaned_data['date']

            register_reminder = Reminder(user_id = user_id,reminder_name = reminder_name,date = reminder_date)
            register_reminder.save()
            reminder_success_alert = True

    fm = RegisterReminder()
    return render(request,'set_reminder.html',{'form': fm,'reminder_success_alert': reminder_success_alert,'date': reminder_date})

def get_view_reminder(request):

    user_id = request.session['user_id']
    username = request.session['username']
    reminder_set = Reminder.objects.filter(user_id = user_id).values()

    # print(reminder_set)
    # for reminder in reminder_set:

    #     print(reminder['user_id'])
    #     print(reminder['reminder_name'])
    #     print(reminder['date'])

    return render(request,'view_reminders.html',{'reminder_set': reminder_set,'username': username})