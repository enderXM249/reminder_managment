from django.contrib import admin
from .models import UserSignUp,Reminder

@admin.register(UserSignUp)
class UserAdmin(admin.ModelAdmin):
    list_display = ['id','username','password']

@admin.register(Reminder)
class ReminderAdmin(admin.ModelAdmin):
    list_display = ['id','reminder_name','date']

