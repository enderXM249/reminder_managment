from django.apps import AppConfig


class RmsAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'rms_app'
