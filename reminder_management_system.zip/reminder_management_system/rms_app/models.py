from django.db import models

class UserSignUp(models.Model):
    username = models.CharField(max_length=50)
    password = models.CharField(max_length=50)

class Reminder(models.Model):
    user_id = models.CharField(max_length=100,default=True)
    reminder_name = models.CharField(max_length=100)
    date = models.DateField()