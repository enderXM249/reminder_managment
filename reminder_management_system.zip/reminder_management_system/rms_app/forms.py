from django import forms
from .models import UserSignUp,Reminder


class RegisterUser(forms.ModelForm):
    class Meta:
        model = UserSignUp
        fields = ['username','password']
        widgets = {
            'username': forms.TextInput(attrs = {'name': 'username','id': 'username','class': 'form-control','placeholder': 'Username'}),
            'password': forms.PasswordInput(attrs = {'name': 'password','id': 'password','class': 'form-control','placeholder': 'Password'})
        }

class UserSignIn(forms.Form):
    username = forms.CharField(widget=forms.TextInput(attrs={
        'name': 'username','id': 'username','class': 'form-control','placeholder': 'Username'
    }))
    password = forms.CharField(widget=forms.PasswordInput(attrs={
        'name': 'password','id': 'password','class': 'form-control','placeholder': 'Password'
    }))

class RegisterReminder(forms.ModelForm):
    class Meta:
        model = Reminder
        fields = ['reminder_name','date']
        widgets = {
            'reminder_name': forms.TextInput(attrs = {'name': 'reminder','id': 'reminder','class': 'form-control','placeholder': 'Reminder'}),
            'date': forms.DateInput(format=('%Y-%m-%d'),attrs = {'type': 'date','name': 'reminder-date','id': 'reminder-date','class': 'form-control','placeholder': 'Select a date'})
        }